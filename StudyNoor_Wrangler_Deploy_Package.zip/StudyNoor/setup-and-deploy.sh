#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "ERROR: Node.js and npm are required. Use a computer or a cloud terminal that has Node.js/npm installed."
  exit 1
fi

npm install
npx wrangler login

echo
echo "Creating Cloudflare KV namespace for sister access and AI usage limits..."
if grep -q 'REPLACE_WITH_KV_NAMESPACE_ID' wrangler.toml; then
  npx wrangler kv namespace create SISTER_ENTITLEMENTS
  echo
  echo "Copy the namespace ID printed above."
  read -r -p "Paste the KV namespace ID here: " KV_ID
  if [[ ! "$KV_ID" =~ ^[a-fA-F0-9-]{20,}$ ]]; then
    echo "ERROR: That does not look like a Cloudflare KV namespace ID. Nothing was deployed."
    exit 1
  fi
  sed -i.bak "s/REPLACE_WITH_KV_NAMESPACE_ID/$KV_ID/" wrangler.toml
  rm -f wrangler.toml.bak
else
  echo "KV namespace ID already appears configured; skipping namespace creation."
fi

read -r -s -p "Enter your AI provider API key (required for real AI): " AI_KEY
printf '\n'
if [[ -z "$AI_KEY" ]]; then
  echo "ERROR: No AI API key provided. The site could deploy, but AI will not work."
  exit 1
fi
printf '%s' "$AI_KEY" | npx wrangler secret put AI_API_KEY
unset AI_KEY

read -r -s -p "Create a private sister access code (keep it secret): " SISTER_CODE
printf '\n'
if [[ -z "$SISTER_CODE" ]]; then
  echo "ERROR: Sister access code cannot be blank."
  exit 1
fi
printf '%s' "$SISTER_CODE" | npx wrangler secret put SISTER_ACCESS_CODE
unset SISTER_CODE

if command -v openssl >/dev/null 2>&1; then
  TOKEN_SECRET="$(openssl rand -hex 32)"
else
  read -r -s -p "Enter a random token secret of at least 32 characters: " TOKEN_SECRET
  printf '\n'
  if [[ ${#TOKEN_SECRET} -lt 32 ]]; then echo "ERROR: Token secret must be at least 32 characters."; exit 1; fi
fi
printf '%s' "$TOKEN_SECRET" | npx wrangler secret put TOKEN_SECRET
unset TOKEN_SECRET

echo
echo "Deploying StudyNoor..."
npx wrangler deploy

echo
echo "Deployment command completed. Open the *.workers.dev URL printed above and test the app."
echo "This does not implement Google Play Billing; do not sell public Premium until billing verification is added and tested."
