# StudyNoor deployment — read before deploying

## Important
The Cloudflare **drag-and-drop uploader cannot deploy this project**, because it includes a Worker configuration. Deploy it with Wrangler from a terminal, or connect a Git repository to Cloudflare Workers Builds and set the deploy command to `npx wrangler deploy`.

The simplest terminal route is:

1. Extract this ZIP.
2. Open a terminal in the `StudyNoor` folder (the folder containing `wrangler.toml`).
3. Make sure Node.js and npm are installed.
4. Run `bash setup-and-deploy.sh`.
5. Follow the prompts. You must have an AI provider API key. Keep it private; the script stores it as a Cloudflare Worker secret, not in the HTML.
6. The script creates the KV namespace, asks you to paste the returned namespace ID into the project configuration, saves the secrets, then deploys.
7. Open the `workers.dev` URL shown by Wrangler and test on your phone.

If your terminal does not support `sed -i.bak`, edit `wrangler.toml` manually and replace `REPLACE_WITH_KV_NAMESPACE_ID` with the namespace ID returned by Cloudflare.

## If you are using only an Android phone
The Cloudflare dashboard's drag-and-drop uploader is not the right tool for this project. Use a cloud development terminal that supports Node.js/npm and can run shell scripts, or ask someone with a computer to run the script. Do not paste API keys into chat or put them in `public/index.html`.

## What deployment does and does not mean
- It deploys the PWA static assets and Worker API together.
- Real AI requires a valid provider key, available model, provider billing, and a successful live request test.
- Sister complimentary access requires the secret code and KV namespace. Redeem it on the intended device only.
- Public monthly/yearly paid subscriptions and Google Play purchase verification are not implemented in this candidate. Do not launch or sell public Premium until those are added and tested.
- Privacy and terms templates must be reviewed and published at real URLs before public launch.
