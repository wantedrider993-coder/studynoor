# StudyNoor Privacy Policy — DRAFT TEMPLATE

**Do not publish this template without filling in every bracketed field and checking it against the actual services you use.**

Last updated: [DATE]

StudyNoor is operated by [YOUR LEGAL NAME / BUSINESS NAME] (“we”, “us”). Contact: [SUPPORT EMAIL].

## Information stored on your device
StudyNoor stores subjects, chapters, study notes, tasks, focus logs, settings, and prayer-tracking choices in the browser's local storage on your device. This information is not automatically synced to an account. Clearing browser/app data may delete it. You can export a local backup from Settings.

## AI study tools
When you use an AI feature, the text you submit and any photo you choose to upload are sent to our server and the AI provider configured for StudyNoor ([PROVIDER NAME AND LINK]) to generate a response. Do not submit passwords, financial details, private identity documents, or information about other people. AI responses may be inaccurate; verify important study material against your syllabus and textbook.

## Premium access and security
Complimentary access codes and Premium entitlement information may be processed by our hosting provider to verify access and prevent unauthorised use. If Google Play Billing is added, subscription and purchase data will be processed as described in the final version of this policy and Google's applicable notices.

## Hosting, retention and third parties
The app/API is hosted using [HOSTING PROVIDER]. AI requests are processed by [AI PROVIDER]. Explain the providers' relevant privacy/data-retention practices here. Do not claim that data is never retained unless you have verified that claim against current provider terms and settings.

## Children's privacy
StudyNoor is designed as a general student tool. [ADD YOUR AGE POLICY AND ANY REQUIRED PARENTAL-CONSENT PROCESS.] Do not publish until this section matches your intended audience and applicable law.

## Your choices and deletion requests
You can stop using AI features at any time. Local data can be deleted from Settings; export a backup first if needed. For help with access-code resets or other requests, contact [SUPPORT EMAIL]. Describe any server-side deletion process here before launch.

## Changes
We may update this policy. The current version and effective date will be published at [PUBLIC POLICY URL].

## Contact
[LEGAL NAME / BUSINESS NAME]
[SUPPORT EMAIL]
[CONTACT ADDRESS OR OTHER REQUIRED CONTACT DETAILS]
