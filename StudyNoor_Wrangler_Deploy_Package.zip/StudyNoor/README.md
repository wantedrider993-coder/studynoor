# StudyNoor — updated release candidate

This package contains the existing StudyNoor study planner with a mature teal/stone visual system, a distinct dark teal-and-gold Premium theme, the AI Studio interface, PWA files, and a Cloudflare Worker API starter.

## What is ready in the code
- Existing local-first tools: subjects, chapters and notes, tasks/exams, planner/calendar, focus timer, progress, Namaz tracker, prayer reminders, and JSON backup/restore.
- AI Studio interface for explanations, smart notes, flashcards, quizzes, memory tricks, personalised study plans, and textbook/photo input.
- Server-side AI provider integration; the provider key is not placed in the browser.
- Private complimentary access-code flow backed by Cloudflare KV. The code is bound to the first device that redeems it; the entitlement is lifetime in KV, while signed access tokens refresh every 30 days.
- A per-device daily AI request cap (default 40, configurable with `AI_DAILY_LIMIT`) to help control API spending.
- PWA manifest, 192/512 PNG icons, maskable icon, SVG favicon and offline service worker.

## Checks run on this release candidate
- Frontend JavaScript and Worker JavaScript syntax checks passed.
- Manifest JSON parsed; all declared icon files exist.
- ZIP integrity check passed.
- Worker tests using a mocked AI provider passed for invalid-code rejection, complimentary-code redemption, token refresh, one-device binding, rejecting unauthenticated/tampered tokens, successful simulated AI responses, and the per-device usage cap.
- The browser and live AI provider could not be verified end-to-end in this workspace. These checks do not prove the deployed site, real provider credentials, Play Billing, or Google Play approval works.

## What cannot be completed from this workspace alone
This ZIP has not been deployed to your Cloudflare account or tested against live credentials. AI calls will not work until you create the KV namespace, configure the secrets, and deploy the Worker. Public paid subscriptions are **not implemented**: Google Play Billing, purchase verification, renewals, cancellations/refunds and customer entitlements must be connected before selling Premium. The ₹49/month price is display text only, not an active checkout. Do not submit it as a paid app yet.

## Required Cloudflare setup
You need a Cloudflare account and a terminal environment with Node.js/npm. Do not paste secret values into HTML, chat, or a public repository.

1. Unzip this project and open a terminal in the `studynoor_release` folder.
2. Install Wrangler if needed: `npm install -g wrangler`.
3. Sign in: `npx wrangler login`.
4. Create the KV namespace: `npx wrangler kv namespace create SISTER_ENTITLEMENTS`.
5. Copy the namespace ID returned by that command into `wrangler.toml`, replacing `REPLACE_WITH_KV_NAMESPACE_ID`.
6. Set secrets individually:
   - `npx wrangler secret put AI_API_KEY` — your AI provider key.
   - `npx wrangler secret put TOKEN_SECRET` — a long random secret (at least 32 random characters).
   - `npx wrangler secret put SISTER_ACCESS_CODE` — a long, private code shared only with your sister.
7. Optional Worker variables can be set in Cloudflare: `AI_MODEL` (default `gpt-4o-mini`), `AI_API_URL` (default OpenAI Responses API), and `AI_DAILY_LIMIT` (default `40`). Check the provider's current model/API availability and set spending alerts/limits.
8. Deploy: `npx wrangler deploy`.
9. Open the deployed HTTPS URL, redeem the private code on the intended device, then test an AI text request and a textbook photo. Review Worker logs and provider usage if a request fails.

The complimentary code is bound to the first device that redeems it. If your sister changes phone or clears the app's local storage, an administrator will need to reset the KV entries (`sister-code-binding` and the matching `entitlement:<deviceId>`) before she can activate a replacement device. This avoids an unrestricted reusable public code, but is not a full account/recovery system.

## Google Play / public launch checklist
- Implement and test Google Play Billing and server-side purchase verification for monthly and annual subscriptions; handle renewals, cancellations, refunds, grace periods and account/device recovery.
- Confirm the annual price before launch. No annual price is hardcoded in this project.
- Publish a real privacy-policy URL and terms; add accurate disclosures for AI processing, uploaded textbook images, local data storage, support contact, and data deletion.
- Add robust abuse controls, monitoring, backup/recovery, and entitlement management.
- Test installation, offline behaviour, AI failures, accessibility, small screens, data export/import, and real Android devices.
- Check current Play Console and PWABuilder requirements. A valid manifest by itself does not guarantee a passing score or store approval.

## Privacy and data handling
Study plans, prayer ticks, and settings are stored in browser local storage on the device. Clearing browser data may erase them, so export backups regularly. When the AI is used, submitted text and any selected photo are sent to your configured Worker and AI provider to generate a response. Before public launch, publish a privacy policy that accurately reflects your chosen provider and its data terms, and obtain appropriate consent.

## Files
- `public/index.html` — app interface and local-first features
- `public/manifest.json` — install metadata
- `public/sw.js` — offline shell caching
- `public/icons/` — app icons
- `worker.js` — server-side AI and complimentary-entitlement API
- `wrangler.toml` — Cloudflare Worker/asset configuration (KV ID must be filled in)
- `PRIVACY_POLICY_TEMPLATE.md` and `TERMS_TEMPLATE.md` — draft documents to review and publish; they are not legal advice
