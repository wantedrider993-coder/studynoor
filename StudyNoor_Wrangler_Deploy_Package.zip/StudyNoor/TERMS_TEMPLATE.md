# StudyNoor Terms of Use — DRAFT TEMPLATE

**Review and complete this document before publication. This is a starter template, not legal advice.**

Effective date: [DATE]
Operator: [LEGAL NAME / BUSINESS NAME]
Contact: [SUPPORT EMAIL]

1. **Purpose.** StudyNoor provides study-planning, productivity, prayer-tracking and, when configured, AI-assisted learning tools.
2. **Accounts and access.** Some features may require a valid complimentary entitlement or paid subscription. Do not share private access codes or attempt to bypass access controls.
3. **AI limitations.** AI-generated explanations, notes, flashcards, quizzes and study plans may contain errors or omissions. You are responsible for checking outputs against official course material. StudyNoor does not guarantee grades, exam results, or academic outcomes.
4. **Acceptable use.** Do not use the service for unlawful activity, abuse, automated scraping, or attempts to disrupt or reverse-engineer protected systems.
5. **Subscriptions.** Before launch, insert the actual monthly and annual prices, billing period, renewal, cancellation, refund, grace-period and entitlement terms that match the implemented Google Play Billing configuration. Do not publish this section until those details are verified.
6. **Availability and data.** The service may change or be unavailable. Study data stored locally may be lost if browser/app data is cleared; export backups regularly. Explain any server-side AI data processing in the Privacy Policy.
7. **Intellectual property.** [DESCRIBE OWNERSHIP AND USER RIGHTS FOR APP CONTENT AND USER-SUBMITTED MATERIAL.] Users must have rights or permission to submit material for processing.
8. **Disclaimers and liability.** [ADD TERMS REVIEWED FOR THE LAWS THAT APPLY TO YOUR OPERATION.] Do not use an unreviewed generic clause as a substitute for legal advice.
9. **Changes and termination.** [DESCRIBE HOW TERMS MAY CHANGE AND HOW ACCESS MAY BE SUSPENDED OR ENDED.]
10. **Contact.** [LEGAL NAME / BUSINESS NAME], [SUPPORT EMAIL].
