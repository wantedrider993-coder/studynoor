// StudyNoor Cloudflare Worker API.
// Required secrets: AI_API_KEY, TOKEN_SECRET, SISTER_ACCESS_CODE.
// Required KV binding: SISTER_ENTITLEMENTS (create a KV namespace and bind it in wrangler.toml).
// Optional vars: AI_MODEL, AI_API_URL.
const enc = new TextEncoder();
const DAY = 24 * 60 * 60 * 1000;
const TOKEN_LIFETIME = 30 * DAY;
function b64u(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_'); }
function unb64u(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); return Uint8Array.from(atob(s + '='.repeat((4 - s.length % 4) % 4)), c => c.charCodeAt(0)); }
async function hmac(data, secret) { const key = await crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']); return new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(data))); }
async function issueToken(secret, deviceId) {
  const payload = b64u(enc.encode(JSON.stringify({ iss: 'studynoor', tier: 'premium', kind: 'complimentary', sub: deviceId, iat: Date.now(), exp: Date.now() + TOKEN_LIFETIME })));
  return payload + '.' + b64u(await hmac(payload, secret));
}
async function readToken(token, secret) {
  try {
    const [p, s, extra] = token.split('.'); if (!p || !s || extra) return null;
    const expected = await hmac(p, secret), got = unb64u(s);
    if (expected.length !== got.length) return null;
    let diff = 0; for (let i = 0; i < expected.length; i++) diff |= expected[i] ^ got[i]; if (diff !== 0) return null;
    const data = JSON.parse(new TextDecoder().decode(unb64u(p)));
    if (data.iss !== 'studynoor' || data.tier !== 'premium' || !data.sub || data.exp <= Date.now()) return null;
    return data;
  } catch { return null; }
}
const headers = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' };
function json(data, status = 200) { return new Response(JSON.stringify(data), { status, headers }); }
function validDeviceId(v) { return typeof v === 'string' && /^[a-f0-9-]{20,80}$/i.test(v); }
async function entitlement(env, deviceId) { if (!env.SISTER_ENTITLEMENTS) return null; try { return await env.SISTER_ENTITLEMENTS.get('entitlement:' + deviceId, 'json'); } catch { return null; } }
export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS ? env.ASSETS.fetch(req) : new Response('StudyNoor static asset binding is not configured.', { status: 503 });
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Max-Age': '86400' } });
    if (req.method !== 'POST') return json({ error: 'Method not allowed.' }, 405);
    if (!env.TOKEN_SECRET) return json({ error: 'Premium access service is not configured.' }, 503);
    if (!env.SISTER_ENTITLEMENTS) return json({ error: 'Complimentary access storage is not configured. Finish the Cloudflare KV setup.' }, 503);

    if (url.pathname === '/api/redeem') {
      if (!env.SISTER_ACCESS_CODE) return json({ error: 'Private access codes are not configured.' }, 503);
      let body; try { body = await req.json(); } catch { return json({ error: 'Invalid request.' }, 400); }
      if (!validDeviceId(body.deviceId)) return json({ error: 'This installation could not be identified. Refresh the app and try again.' }, 400);
      if (typeof body.code !== 'string' || body.code.length > 200 || body.code.trim() !== env.SISTER_ACCESS_CODE) return json({ error: 'That access code is not valid.' }, 403);
      const deviceId = body.deviceId;
      const existing = await env.SISTER_ENTITLEMENTS.get('sister-code-binding');
      if (existing && existing !== deviceId) return json({ error: 'This private lifetime code has already been activated on its registered device. Contact the app owner if the device changed.' }, 409);
      // Bind the complimentary lifetime entitlement to the first device that redeems the private code.
      await env.SISTER_ENTITLEMENTS.put('sister-code-binding', deviceId);
      await env.SISTER_ENTITLEMENTS.put('entitlement:' + deviceId, JSON.stringify({ tier: 'premium', kind: 'complimentary-lifetime', createdAt: new Date().toISOString() }));
      return json({ token: await issueToken(env.TOKEN_SECRET, deviceId), tier: 'premium', kind: 'complimentary-lifetime' });
    }

    if (url.pathname === '/api/refresh') {
      let body; try { body = await req.json(); } catch { return json({ error: 'Invalid request.' }, 400); }
      if (!validDeviceId(body.deviceId)) return json({ error: 'Invalid installation identifier.' }, 400);
      const ent = await entitlement(env, body.deviceId);
      if (!ent || ent.tier !== 'premium') return json({ error: 'No complimentary Premium entitlement was found for this installation.' }, 401);
      return json({ token: await issueToken(env.TOKEN_SECRET, body.deviceId), tier: 'premium', kind: ent.kind || 'complimentary-lifetime' });
    }

    if (url.pathname === '/api/ai') {
      const auth = req.headers.get('Authorization') || '';
      if (!auth.startsWith('Bearer ')) return json({ error: 'Premium access is required. Redeem your private code.' }, 401);
      const claims = await readToken(auth.slice(7), env.TOKEN_SECRET);
      if (!claims) return json({ error: 'Your Premium session expired. Reopen the app while online to refresh access.' }, 401);
      const ent = await entitlement(env, claims.sub);
      if (!ent || ent.tier !== 'premium') return json({ error: 'Premium access could not be verified.' }, 401);
      if (!env.AI_API_KEY) return json({ error: 'AI service is not configured yet.' }, 503);
      // Simple per-device daily cap to help control unexpected provider costs.
      const dayKey = new Date().toISOString().slice(0, 10);
      const usageKey = `ai-usage:${claims.sub}:${dayKey}`;
      const used = Number(await env.SISTER_ENTITLEMENTS.get(usageKey) || 0);
      const dailyLimit = Math.max(1, Math.min(200, Number(env.AI_DAILY_LIMIT) || 40));
      if (used >= dailyLimit) return json({ error: `Daily AI limit reached (${dailyLimit} requests). Please try again tomorrow.` }, 429);
      let body; try { body = await req.json(); } catch { return json({ error: 'Invalid request.' }, 400); }
      const modes = {
        explain: 'Explain the topic in clear, student-friendly language with an example and a short recap.',
        notes: 'Create structured revision notes with headings, key definitions, important points and a short summary. Do not invent facts not supported by the supplied material.',
        flashcards: 'Create 8 to 12 question-and-answer flashcards for active recall.',
        quiz: 'Create 8 multiple-choice questions with four options each, the correct answer and a short explanation. Put the answer key after all questions.',
        memory: 'Give memorable mnemonics, associations and recall cues without changing the factual meaning.',
        plan: 'Create a realistic study plan using the topic, available time and deadlines stated by the student. Ask for missing critical details if needed.'
      };
      const mode = modes[body.mode] || modes.explain;
      const prompt = String(body.prompt || '').slice(0, 20000);
      const subject = String(body.subject || '').slice(0, 300);
      if (body.image && (!/^data:image\/(png|jpeg|webp);base64,/.test(body.image) || body.image.length > 11_500_000)) return json({ error: 'Image must be a PNG, JPG or WebP under 8 MB.' }, 400);
      if (!prompt && !body.image) return json({ error: 'Add a topic, text or image first.' }, 400);
      await env.SISTER_ENTITLEMENTS.put(usageKey, String(used + 1), { expirationTtl: 48 * 60 * 60 });
      const content = [{ type: 'input_text', text: `You are StudyNoor, a careful study tutor. ${mode}\nSubject: ${subject || 'Not specified'}\nStudent material/request:\n${prompt || 'Please read the attached study image and help me learn it.'}\n\nUse clear, age-appropriate language for a college student. Be accurate, organised and concise. If the image or text is unclear, say so instead of guessing.` }];
      if (body.image) content.push({ type: 'input_image', image_url: body.image, detail: 'high' });
      const apiUrl = env.AI_API_URL || 'https://api.openai.com/v1/responses';
      let upstream;
      try { upstream = await fetch(apiUrl, { method: 'POST', headers: { 'Authorization': `Bearer ${env.AI_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: env.AI_MODEL || 'gpt-4o-mini', input: [{ role: 'user', content }], max_output_tokens: 1800 }) }); }
      catch { return json({ error: 'Could not reach the AI provider. Please try again.' }, 502); }
      let result; try { result = await upstream.json(); } catch { return json({ error: 'The AI provider returned an unreadable response.' }, 502); }
      if (!upstream.ok) return json({ error: 'The AI provider could not complete this request. Check the server configuration or provider usage limits.' }, 502);
      let textOut = '';
      if (Array.isArray(result.output)) for (const item of result.output) if (item.type === 'message' && Array.isArray(item.content)) for (const part of item.content) if (part.type === 'output_text') textOut += part.text;
      if (!textOut) textOut = result.output_text || '';
      if (!textOut) return json({ error: 'The AI returned no text. Try a shorter request.' }, 502);
      return json({ text: textOut.slice(0, 24000) });
    }
    return json({ error: 'Not found.' }, 404);
  }
};
